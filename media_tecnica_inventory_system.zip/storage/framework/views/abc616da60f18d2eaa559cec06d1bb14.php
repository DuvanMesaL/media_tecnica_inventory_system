<?php $__env->startSection('title', 'Tools Report'); ?>
<?php $__env->startSection('header', 'Tools Inventory Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Summary Statistics -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-boxes text-2xl text-blue-600"></i>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Total Tools</dt>
                            <dd class="text-lg font-bold text-gray-900"><?php echo e(number_format($summary['total_tools'])); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-dollar-sign text-2xl text-green-600"></i>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Total Value</dt>
                            <dd class="text-lg font-bold text-gray-900">$<?php echo e(number_format($summary['total_value'], 2)); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-triangle text-2xl text-red-600"></i>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Out of Stock</dt>
                            <dd class="text-lg font-bold text-gray-900"><?php echo e($summary['out_of_stock']); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-circle text-2xl text-yellow-600"></i>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Low Stock</dt>
                            <dd class="text-lg font-bold text-gray-900"><?php echo e($summary['low_stock']); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters and Export -->
    <div class="bg-white shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-medium text-gray-900">Filter Tools</h3>
                <a href="<?php echo e(route('reports.export', 'tools')); ?>"
                   class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                    <i class="fas fa-download mr-2"></i>Export CSV
                </a>
            </div>

            <form method="GET" class="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Warehouse</label>
                    <select name="warehouse_id" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <option value="">All Warehouses</option>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($warehouse->id); ?>" <?php echo e(request('warehouse_id') == $warehouse->id ? 'selected' : ''); ?>>
                                <?php echo e($warehouse->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select name="category" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <option value="">All Categories</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category); ?>" <?php echo e(request('category') === $category ? 'selected' : ''); ?>>
                                <?php echo e($category); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Condition</label>
                    <select name="condition" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <option value="">All Conditions</option>
                        <option value="good" <?php echo e(request('condition') === 'good' ? 'selected' : ''); ?>>Good</option>
                        <option value="damaged" <?php echo e(request('condition') === 'damaged' ? 'selected' : ''); ?>>Damaged</option>
                        <option value="lost" <?php echo e(request('condition') === 'lost' ? 'selected' : ''); ?>>Lost</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Stock Level</label>
                    <select name="stock_level" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <option value="">All Levels</option>
                        <option value="out_of_stock" <?php echo e(request('stock_level') === 'out_of_stock' ? 'selected' : ''); ?>>Out of Stock</option>
                        <option value="low_stock" <?php echo e(request('stock_level') === 'low_stock' ? 'selected' : ''); ?>>Low Stock (≤5)</option>
                        <option value="adequate_stock" <?php echo e(request('stock_level') === 'adequate_stock' ? 'selected' : ''); ?>>Adequate Stock (>5)</option>
                    </select>
                </div>

                <div class="flex items-end">
                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                        <i class="fas fa-filter mr-1"></i>Apply Filters
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Tools Table -->
    <div class="bg-white shadow overflow-hidden sm:rounded-md">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tool</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Condition</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usage</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div>
                                    <div class="text-sm font-medium text-gray-900"><?php echo e($tool->name); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo e($tool->code); ?> - <?php echo e($tool->category); ?></div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo e($tool->warehouse->name); ?></div>
                                <div class="text-sm text-gray-500"><?php echo e($tool->warehouse->location); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900">
                                    Available: <span class="font-medium <?php echo e($tool->available_quantity <= 5 ? 'text-red-600' : ($tool->available_quantity <= 10 ? 'text-yellow-600' : 'text-green-600')); ?>">
                                        <?php echo e($tool->available_quantity); ?>

                                    </span>
                                </div>
                                <div class="text-sm text-gray-500">Total: <?php echo e($tool->total_quantity); ?></div>
                                <div class="text-sm text-blue-600">On Loan: <?php echo e($tool->total_quantity - $tool->available_quantity); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                    <?php if($tool->condition === 'good'): ?> bg-green-100 text-green-800
                                    <?php elseif($tool->condition === 'damaged'): ?> bg-yellow-100 text-yellow-800
                                    <?php else: ?> bg-red-100 text-red-800
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst($tool->condition)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php if($tool->unit_price): ?>
                                    <div>Unit: $<?php echo e(number_format($tool->unit_price, 2)); ?></div>
                                    <div class="font-medium">Total: $<?php echo e(number_format($tool->total_quantity * $tool->unit_price, 2)); ?></div>
                                <?php else: ?>
                                    <span class="text-gray-400">Not specified</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <div class="flex items-center">
                                    <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                        <?php
                                            $usage_percentage = $tool->total_quantity > 0 ? (($tool->total_quantity - $tool->available_quantity) / $tool->total_quantity) * 100 : 0;
                                        ?>
                                        <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo e($usage_percentage); ?>%"></div>
                                    </div>
                                    <span class="text-xs"><?php echo e(round($usage_percentage)); ?>%</span>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                                No tools found matching the selected criteria.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        <?php echo e($tools->appends(request()->query())->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\media_tecnica_inventory_system\resources\views/reports/tools.blade.php ENDPATH**/ ?>