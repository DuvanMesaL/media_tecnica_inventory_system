¡Has sido invitado!
<?php echo e(config('app.name')); ?>


Hola,

<?php echo e($invitedBy->name); ?> te ha invitado a unirte al <?php echo e(config('app.name')); ?>.

Detalles de tu invitación:
- Correo: <?php echo e($invitation->email); ?>

- Rol: <?php echo e($roleName); ?>

<?php if($invitation->technicalProgram): ?>
- Programa: <?php echo e($invitation->technicalProgram->name); ?>

<?php endif; ?>
- Invitado por: <?php echo e($invitedBy->name); ?>


Para completar tu registro y acceder al sistema, visita el siguiente enlace:
<?php echo e($acceptUrl); ?>


IMPORTANTE: Esta invitación expira el <?php echo e($expiresAt->format('d/m/Y \a \l\a\s H:i')); ?>.

Si tienes alguna pregunta, no dudes en contactar a <?php echo e($invitedBy->name); ?> o al administrador del sistema.

¡Esperamos verte pronto en el sistema!

---
Este correo fue enviado desde <?php echo e(config('app.name')); ?>

Si no esperabas esta invitación, puedes ignorar este correo.
<?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\media_tecnica_inventory_system\resources\views/emails/user-invitation-text.blade.php ENDPATH**/ ?>