<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificación de Préstamo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            <?php if($type === 'approved'): ?>
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            <?php elseif($type === 'delivered'): ?>
            background: linear-gradient(135deg, #007bff 0%, #6610f2 100%);
            <?php elseif($type === 'overdue'): ?>
            background: linear-gradient(135deg, #dc3545 0%, #fd7e14 100%);
            <?php else: ?>
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            <?php endif; ?>
            color: white;
            padding: 30px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }
        .content {
            background: #f8f9fa;
            padding: 30px;
            border-radius: 0 0 10px 10px;
        }
        .button {
            display: inline-block;
            background: #007bff;
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px 0;
            font-weight: bold;
        }
        .info-box {
            background: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 15px;
            margin: 20px 0;
        }
        .tools-list {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin: 15px 0;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>
            <?php if($type === 'approved'): ?>
                ✅ Préstamo Aprobado
            <?php elseif($type === 'delivered'): ?>
                📦 Préstamo Entregado
            <?php elseif($type === 'returned'): ?>
                🔄 Préstamo Devuelto
            <?php elseif($type === 'overdue'): ?>
                ⚠️ Préstamo Vencido
            <?php else: ?>
                📋 Notificación de Préstamo
            <?php endif; ?>
        </h1>
        <p><?php echo e($loan->loan_number); ?></p>
    </div>

    <div class="content">
        <h2>Hola <?php echo e($loan->user->full_name); ?>,</h2>

        <?php if($type === 'approved'): ?>
            <p>¡Excelente noticia! Tu solicitud de préstamo ha sido <strong>aprobada</strong> y las herramientas han sido reservadas para ti.</p>
        <?php elseif($type === 'delivered'): ?>
            <p>Tu préstamo ha sido <strong>entregado</strong> exitosamente. Ya puedes usar las herramientas solicitadas.</p>
        <?php elseif($type === 'returned'): ?>
            <p>Tu préstamo ha sido <strong>devuelto</strong> y procesado correctamente. Gracias por usar nuestro sistema.</p>
        <?php elseif($type === 'overdue'): ?>
            <p><strong>Atención:</strong> Tu préstamo está <strong>vencido</strong>. Por favor, devuelve las herramientas lo antes posible.</p>
        <?php endif; ?>

        <div class="info-box">
            <h3>📋 Detalles del préstamo:</h3>
            <ul>
                <li><strong>Número:</strong> <?php echo e($loan->loan_number); ?></li>
                <li><strong>Fecha de préstamo:</strong> <?php echo e($loan->loan_date->format('d/m/Y')); ?></li>
                <li><strong>Fecha de devolución esperada:</strong> <?php echo e($loan->expected_return_date->format('d/m/Y')); ?></li>
                <li><strong>Programa:</strong> <?php echo e($loan->technicalProgram->name); ?></li>
                <li><strong>Aula:</strong> <?php echo e($loan->classroom->name); ?></li>
                <li><strong>Estado:</strong>
                    <?php if($loan->status === 'approved'): ?>
                        <span style="color: #28a745;">Aprobado</span>
                    <?php elseif($loan->status === 'delivered'): ?>
                        <span style="color: #007bff;">Entregado</span>
                    <?php elseif($loan->status === 'returned'): ?>
                        <span style="color: #6c757d;">Devuelto</span>
                    <?php else: ?>
                        <?php echo e(ucfirst($loan->status)); ?>

                    <?php endif; ?>
                </li>
            </ul>
        </div>

        <div class="tools-list">
            <h3>🔧 Herramientas:</h3>
            <ul>
                <?php $__currentLoopData = $loan->toolLoanItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <strong><?php echo e($item->tool->name); ?></strong>
                        (<?php echo e($item->quantity_requested); ?> <?php echo e($item->quantity_requested > 1 ? 'unidades' : 'unidad'); ?>)
                        <?php if($item->tool->code): ?>
                            - Código: <?php echo e($item->tool->code); ?>

                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <?php if($type === 'approved'): ?>
            <p><strong>Próximos pasos:</strong></p>
            <ul>
                <li>Dirígete al almacén para recoger las herramientas</li>
                <li>Presenta tu identificación y menciona el número de préstamo</li>
                <li>Verifica que todas las herramientas estén en buen estado</li>
            </ul>
        <?php elseif($type === 'delivered'): ?>
            <p><strong>Recordatorios importantes:</strong></p>
            <ul>
                <li>Cuida las herramientas durante su uso</li>
                <li>Devuélvelas en la fecha acordada</li>
                <li>Reporta cualquier daño inmediatamente</li>
            </ul>
        <?php elseif($type === 'overdue'): ?>
            <p><strong>Acción requerida:</strong></p>
            <ul>
                <li>Devuelve las herramientas lo antes posible</li>
                <li>Contacta al personal de logística si hay algún problema</li>
                <li>Los préstamos vencidos pueden afectar futuras solicitudes</li>
            </ul>
        <?php endif; ?>

        <div style="text-align: center;">
            <a href="<?php echo e($loanUrl); ?>" class="button">
                Ver Detalles del Préstamo
            </a>
        </div>

        <p>Si tienes alguna pregunta o necesitas asistencia, no dudes en contactar al personal de logística.</p>
    </div>

    <div class="footer">
        <p>Este correo fue enviado desde <?php echo e(config('app.name')); ?></p>
        <p>Fecha: <?php echo e(now()->format('d/m/Y H:i')); ?></p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\media_tecnica_inventory_system\resources\views/emails/loan-notification.blade.php ENDPATH**/ ?>