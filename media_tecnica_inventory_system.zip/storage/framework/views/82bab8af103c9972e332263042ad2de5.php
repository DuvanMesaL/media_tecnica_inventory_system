<?php if($type === 'approved'): ?>
✅ Préstamo Aprobado
<?php elseif($type === 'delivered'): ?>
📦 Préstamo Entregado
<?php elseif($type === 'returned'): ?>
🔄 Préstamo Devuelto
<?php elseif($type === 'overdue'): ?>
⚠️ Préstamo Vencido
<?php else: ?>
📋 Notificación de Préstamo
<?php endif; ?>

<?php echo e($loan->loan_number); ?>


Hola <?php echo e($loan->user->full_name); ?>,

<?php if($type === 'approved'): ?>
¡Excelente noticia! Tu solicitud de préstamo ha sido APROBADA y las herramientas han sido reservadas para ti.
<?php elseif($type === 'delivered'): ?>
Tu préstamo ha sido ENTREGADO exitosamente. Ya puedes usar las herramientas solicitadas.
<?php elseif($type === 'returned'): ?>
Tu préstamo ha sido DEVUELTO y procesado correctamente. Gracias por usar nuestro sistema.
<?php elseif($type === 'overdue'): ?>
ATENCIÓN: Tu préstamo está VENCIDO. Por favor, devuelve las herramientas lo antes posible.
<?php endif; ?>

Detalles del préstamo:
- Número: <?php echo e($loan->loan_number); ?>

- Fecha de préstamo: <?php echo e($loan->loan_date->format('d/m/Y')); ?>

- Fecha de devolución esperada: <?php echo e($loan->expected_return_date->format('d/m/Y')); ?>

- Programa: <?php echo e($loan->technicalProgram->name); ?>

- Aula: <?php echo e($loan->classroom->name); ?>

- Estado: <?php echo e(ucfirst($loan->status)); ?>


Herramientas:
<?php $__currentLoopData = $loan->toolLoanItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($item->tool->name); ?> (<?php echo e($item->quantity_requested); ?> <?php echo e($item->quantity_requested > 1 ? 'unidades' : 'unidad'); ?>)<?php if($item->tool->code): ?> - Código: <?php echo e($item->tool->code); ?><?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($type === 'approved'): ?>
Próximos pasos:
- Dirígete al almacén para recoger las herramientas
- Presenta tu identificación y menciona el número de préstamo
- Verifica que todas las herramientas estén en buen estado
<?php elseif($type === 'delivered'): ?>
Recordatorios importantes:
- Cuida las herramientas durante su uso
- Devuélvelas en la fecha acordada
- Reporta cualquier daño inmediatamente
<?php elseif($type === 'overdue'): ?>
Acción requerida:
- Devuelve las herramientas lo antes posible
- Contacta al personal de logística si hay algún problema
- Los préstamos vencidos pueden afectar futuras solicitudes
<?php endif; ?>

Ver detalles completos: <?php echo e($loanUrl); ?>


Si tienes alguna pregunta o necesitas asistencia, no dudes en contactar al personal de logística.

---
Este correo fue enviado desde <?php echo e(config('app.name')); ?>

Fecha: <?php echo e(now()->format('d/m/Y H:i')); ?>

<?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\media_tecnica_inventory_system\resources\views/emails/loan-notification-text.blade.php ENDPATH**/ ?>