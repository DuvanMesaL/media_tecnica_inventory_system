<?php $__env->startSection('title', 'Completar Perfil'); ?>
<?php $__env->startSection('header', 'Completar Perfil'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900">Completa tu perfil</h3>
                <p class="mt-1 text-sm text-gray-600">
                    Para continuar usando el sistema, necesitas completar tu información personal.
                </p>
            </div>

            <form method="POST" action="<?php echo e(route('profile.complete')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>

                <?php if($errors->any()): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                        <ul class="list-disc list-inside text-sm">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(session('success')): ?>
                    <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <!-- Personal Information -->
                <div class="space-y-4">
                    <h4 class="text-md font-medium text-gray-900">Información Personal</h4>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="first_name" class="block text-sm font-medium text-gray-700">Nombre *</label>
                            <input type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', $user->first_name)); ?>" required
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="middle_name" class="block text-sm font-medium text-gray-700">Segundo Nombre</label>
                            <input type="text" name="middle_name" id="middle_name" value="<?php echo e(old('middle_name', $user->middle_name)); ?>"
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="last_name" class="block text-sm font-medium text-gray-700">Apellido Paterno *</label>
                            <input type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name', $user->last_name)); ?>" required
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="second_last_name" class="block text-sm font-medium text-gray-700">Apellido Materno</label>
                            <input type="text" name="second_last_name" id="second_last_name" value="<?php echo e(old('second_last_name', $user->second_last_name)); ?>"
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="identification_number" class="block text-sm font-medium text-gray-700">Número de Identificación *</label>
                            <input type="text" name="identification_number" id="identification_number" value="<?php echo e(old('identification_number', $user->identification_number)); ?>" required
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="phone_number" class="block text-sm font-medium text-gray-700">Teléfono</label>
                            <input type="tel" name="phone_number" id="phone_number" value="<?php echo e(old('phone_number', $user->phone_number)); ?>"
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>

                    <?php if($user->hasRole('teacher')): ?>
                    <div>
                        <label for="technical_program_id" class="block text-sm font-medium text-gray-700">Programa Técnico *</label>
                        <select name="technical_program_id" id="technical_program_id" required
                                class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Seleccionar Programa</option>
                            <?php $__currentLoopData = $technicalPrograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($program->id); ?>" <?php echo e(old('technical_program_id', $user->technical_program_id) == $program->id ? 'selected' : ''); ?>>
                                    <?php echo e($program->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Password Change (if needed) -->
                <?php if(!$user->password_changed): ?>
                <div class="space-y-4">
                    <h4 class="text-md font-medium text-gray-900">Cambiar Contraseña</h4>
                    <p class="text-sm text-gray-600">Debes establecer una nueva contraseña para tu cuenta.</p>

                    <div>
                        <label for="current_password" class="block text-sm font-medium text-gray-700">Contraseña Actual *</label>
                        <input type="password" name="current_password" id="current_password" required
                               class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="password" class="block text-sm font-medium text-gray-700">Nueva Contraseña *</label>
                            <input type="password" name="password" id="password" required
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="password_confirmation" class="block text-sm font-medium text-gray-700">Confirmar Contraseña *</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" required
                                   class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="flex justify-end space-x-3">
                    <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md text-sm font-medium transition-colors">
                        <i class="fas fa-check mr-2"></i>Completar Perfil
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\media_tecnica_inventory_system\resources\views/auth/complete-profile.blade.php ENDPATH**/ ?>