¡Bienvenido <?php echo e($user->first_name); ?>!
Tu cuenta ha sido creada exitosamente

Hola <?php echo e($user->full_name); ?>,

¡Felicidades! Tu cuenta en el <?php echo e(config('app.name')); ?> ha sido creada exitosamente y ya puedes comenzar a usar todas las funcionalidades del sistema.

Accede al sistema: <?php echo e($dashboardUrl); ?>


Primeros pasos recomendados:
1. Explora el dashboard - Familiarízate con la interfaz
<?php if($user->hasRole('teacher')): ?>
2. Revisa el inventario - Ve qué herramientas están disponibles
3. Solicita tu primer préstamo - Prueba el proceso completo
<?php elseif($user->hasRole('logistics')): ?>
2. Revisa los préstamos pendientes - Ve si hay solicitudes por aprobar
3. Explora los reportes - Conoce las estadísticas del sistema
<?php else: ?>
2. Revisa la configuración - Asegúrate de que todo esté configurado correctamente
3. Explora los reportes - Conoce el estado general del sistema
<?php endif; ?>
4. Actualiza tu perfil - Agrega información adicional si es necesario

Funcionalidades principales:
<?php if($user->hasRole('teacher')): ?>
- Solicitar préstamos de herramientas
- Ver el estado de tus préstamos
- Consultar inventario disponible
- Ver historial de préstamos
<?php elseif($user->hasRole('logistics')): ?>
- Gestionar inventario de herramientas
- Aprobar y procesar préstamos
- Generar reportes de uso
- Procesar devoluciones
<?php else: ?>
- Administrar usuarios y permisos
- Gestión completa del inventario
- Acceso a todos los reportes
- Configuración del sistema
<?php endif; ?>

¿Necesitas ayuda?
Si tienes alguna pregunta o necesitas asistencia, no dudes en contactar al administrador del sistema.

¡Esperamos que tengas una excelente experiencia usando nuestro sistema!

Saludos cordiales,
El equipo de <?php echo e(config('app.name')); ?>


---
Este correo fue enviado desde <?php echo e(config('app.name')); ?>

Fecha de registro: <?php echo e($user->created_at->format('d/m/Y H:i')); ?>

<?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\media_tecnica_inventory_system\resources\views/emails/welcome-text.blade.php ENDPATH**/ ?>